
#this file contains no functions, it reads spectra computed with the other functions and plots them;
#it is not very interesting, matplotlib gore, and "post production" is still needed to have a nice output...

from matplotlib.pyplot import subplots, show;	from matplotlib import rc
rc('font',**{'family':'sans-serif'});	rc('text', usetex=True)

from lecture_spectres import lecture_spectres_calcules

PT_scp, S_scp_the = lecture_spectres_calcules("../outputs/output_spectre_pu_avant_desintegrations_SCP.dat");
PT_scp, S_scp_tot = lecture_spectres_calcules("../outputs/output_spectre_pu_apres_desintegrations_SCP.dat")

PT_cf, S_cf_the = lecture_spectres_calcules("../outputs/output_spectre_surface_avant_desintegrations.dat");	
PT_cf, S_cf_tot = lecture_spectres_calcules("../outputs/output_spectre_surface_apres_desintegrations.dat")

P = [r'$\pi$', r'$K$', r'$p$']
	
fig, ax = subplots(3, 3)
for p in range(len(P)):
	ax[0][p].plot(PT_cf, S_cf_the[p], color='tab:blue', linewidth=1, linestyle='solid')
	ax[0][p].plot(PT_scp, S_scp_the[p], color='tab:blue', linewidth=1, linestyle='dashed')
	
	ax[0][p].plot(PT_cf, S_cf_tot[p], color='tab:orange', linewidth=1, linestyle='solid')
	ax[0][p].plot(PT_scp, S_scp_tot[p], color='tab:orange', linewidth=1, linestyle='dashed')
	
	ax[0][0].plot([], [], label=r'Cooper Frye', color='black', linewidth=1, linestyle='solid')
	ax[0][0].plot([], [], label=r'Semi-CF', color='black', linewidth=1, linestyle='dashed')
	
	ax[0][p].set_xlim(0, 3);	ax[0][p].set_ylim(0, max(S_scp_tot[p])*1.1)
	ax[0][p].set_xlabel(r'$p_t\ (\mathrm{GeV})$');
	ax[0][0].set_ylabel(r'$dN/dp_tdy\ (\mathrm{GeV}^{-1})$');
	ax[0][p].set_title(P[p])
ax[0][0].legend(loc='best')

show()