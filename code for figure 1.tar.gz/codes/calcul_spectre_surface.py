
from math import exp, sqrt, pi, cos, sin, cosh, sinh; from scipy.integrate import dblquad
from lecture_composantes_fi import lecture_composantes_fi, lecture_coefficients_f;	from calcul_pu_surface import lecture
	
#this function takes as input an array from lecture_composantes_fi and a freeze-out surface 
#from the lecture function of calcul_pu_surface.py, and returns the transverse momentum 
#spectrum computed using the Cooper-Frye formula, equations (1), (7), (5) of the article 

#it is essentially the same as the function calcul_spectre_pu
#the spectrum is written in DN[particle][pt], and stored in a file

def calcul_spectre_surface():
	print("Calcul spectre surface");	
	
	PBAR, M, FEQ1, FEQ2 = 0, 1, 2, 3;	TAU, SIG_TAU, SIG_X, SIG_Y, U_TAU, U_X, U_Y = 0, 4, 5, 6, 8, 9, 10;
	
	#I don't know why, but here I did not put the fi components etc as 
	#arguments of the function, so I had to set everything up inside of it
	
	C = lecture_composantes_fi("thermal_T0.1350_Fj.out")
	S = lecture("../../surface-50.dat");	print("Lecture surface MUSIC : "+str(len(S[0]))+" cellules");	
	
	#these are some useful things, the P contains the names of the particles we compute 
	#the spectra; it is useful only to write loops; M contains their masses, S their spin
	
	P = ['pi', 'K', 'p'];	M = [0.14, 0.494, 0.9383];	SPI = [0, 0, 0.5];	Tf = 0.135
	
	#this is the range of pt, and for integration in (7)
	#(I wrote it in terms of the rapidity y this time)
	#it is supposed to be inf, but this would take too long
	
	minpt = 1e-4;	maxpt = 3.0; Npt=31;	maxy = 3.;	Ny = 31.;	Nphi = 30.
	PT = [minpt + (maxpt - minpt)*(pt**2)/(Npt - 1)**2 for pt in range(Npt)];	
	
	DN = [];
	for p in range(len(P)): #for every particle we are interested in
		print("\tparticule: "+str(p+1)+" / "+str(len(P)));
		
		DN.append([])
		for pt in range(len(PT)): #for all values of PT
			if(pt%1==0): print("\t\tvaleur de pt: "+str(pt+1)+" / "+str(len(PT))	)
			
			DN[-1].append(0)
			for s in range(len(S[0])): #integration over all the cells of the freeze-out surface
				
				def integrande(y, phi):
					
					#first, we translate y, phi into p0, px and py to compute E* = p^mu u_mu
					p0 = cosh(y)*sqrt(PT[pt]**2+M[p]**2);	px = PT[pt]*cos(phi);	py = PT[pt]*sin(phi)
					Estar = p0*S[U_TAU][s] - px*S[U_X][s] - py*S[U_Y][s];	
					
					#then, we fetch the corresponding f1(E*) and f2(E*) using the dedicated function
					f1, f2 = lecture_coefficients_f([C[h][p] for h in range(len(C))], sqrt(Estar**2 - M[p]**2))
					
					#we add the contribution of this cell of the surface to the integrand, equations (1) and (5)
					r = f1*(p0*S[SIG_TAU][s]+px*S[SIG_X][s]+py*S[SIG_Y][s])*S[TAU][s]*5.068**3
					r += (f2 - f1)*Estar*(S[U_TAU][s]*S[SIG_TAU][s]+S[U_X][s]*S[SIG_X][s]+S[U_Y][s]*S[SIG_Y][s])*S[TAU][s]*5.068**3
					return r
				
				#this integrande shall be integraded over all values of y and phi, equation (7)
				for y in range(int(Ny)):
					for phi in range(int(Nphi)):
						DN[-1][-1]+=4*integrande(maxy*y/(Ny-1), pi*phi/Nphi)*maxy/(Ny-1)*pi/Nphi
			
			#and finally, we shall not forget the factor:
			DN[-1][-1] *= PT[pt]*(2*SPI[p]+1)/(2*pi)**3
	
	#this computation has not been optimized and takes a while, so we better store the result in a file
	#the first row are the values of pt, and the three next are the spectra, for pions, kaons and protons
	
	f = open("output_spectre_surface_avant_desintegrations.dat", mode='w')
	for pt in range(len(PT)):
		f.write(str(PT[pt]))
		for p in range(len(P)): f.write('\t'+str(DN[p][pt]))
		f.write('\n')
	f.close()	
	
	return PT, DN
	
#call the function to 
#do the computation
calcul_spectre_surface()

