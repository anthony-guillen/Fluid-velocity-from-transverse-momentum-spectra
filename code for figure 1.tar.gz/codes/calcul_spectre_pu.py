
from math import sqrt, exp, pi, cos, cosh, asinh;	from numpy import arange
from scipy.integrate import dblquad

from lecture_composantes_fi import lecture_composantes_fi, lecture_coefficients_f
from calcul_pu_surface import calcul_pu_surface

#this function takes as input an array from lecture_composantes_fi, an array with values of transverse 
#momentum pt, an array with values of fluid velocity u, and a corresponding distribution of fluid 
#velocity from calcul_pu_surface, and returns the transverse momentum spectrum computed using 
#the Semi-Cooper-Frye approximation, that is equations (10), (12) and (6) of the article

#the spectrum is written in S[particle][pt], but most importantly, it is stored in a file

def calcul_spectre_pu(C, PT, U, PU):
	
	print("Calcul spectre p(u)")
	
	#these are some useful things, the P contains the names of the particles we compute 
	#the spectra; it is useful only to write loops; M contains their masses, S their spin
	
	P = ['pi', 'K', 'p'];	M = [0.14, 0.494, 0.9383];	SPI = [0, 0, 0.5]
	
	#this is the range of integration over pz for (6) 
	#(we wrote it in terms of the pseudorapidity eta)
	#it is supposed to be inf, but this would take too long
	
	maxeta = 3.;	
	
	S = []
	for p in range(len(P)): #for every particle we are interested in
		print("\tparticule: "+str(p+1)+" / "+str(len(P)))
		
		S.append([])
		for pt in range(len(PT)): #for all values of pt
			if(pt%10==0): print("\t\tvaleur de pt: "+str(pt+1)+" / "+str(len(PT)))
			
			S[-1].append(0);
			for u in range(len(U)): #integration over all values of u, equation (10)
				
				def integrande(eta, phi):
					
					#first, we compute E* using equation (8) of the article
					Estar = sqrt((1+U[u]**2)*(M[p]**2+cosh(eta)**2*PT[pt]**2))-U[u]*PT[pt]*cos(phi)
					
					#then, we fetch the corresponding f1(E*) and f2(E*) using the dedicated function
					f1, f2 = lecture_coefficients_f([C[h][p] for h in range(len(C))], sqrt(Estar**2 - M[p]**2))
					
					#and this is the integrande in equation (12) and using (6)
					return PT[pt]*cosh(eta)*(f1+(f2-f1)*Estar*sqrt(1+U[u]**2)/sqrt(M[p]**2+cosh(eta)**2*PT[pt]**2))
				
				#finally, this integrande shall be integraded over all values of eta and phi, equation (12), and multiplied by PU[u], equation (10)
				S[-1][-1] += 4*dblquad(lambda eta, phi: integrande(eta, phi), 0, pi, lambda eta: 0, lambda eta: maxeta, epsrel=1e-3)[0]*PU[u]
			
			#this is to be repeated for every value of u contained in U, and summed (integrated) over, as equation (10) tells
			
			#and finally, we shall not forget the factor:
			S[-1][-1] *= PT[pt]*(2*SPI[p]+1)/(2*pi)**3
	
	#this computation has not been optimized and takes a while, so we better store the result in a file
	#the first row are the values of pt, and the three next are the spectra, for pions, kaons and protons
	
	f = open("output_spectre_pu_apres_desintegrations_SCP.dat", mode='w')
	for pt in range(len(PT)):
		f.write(str(PT[pt]))
		for p in range(len(P)):
			f.write('\t'+str(S[p][pt]))
		f.write('\n')
	f.close()
	
	return S

#here, we set up everything and call the above function to compute the spectrum and store it

minpt = 1e-4;	maxpt = 3.0; Npt=31;	PT = [minpt + (maxpt - minpt)*(pt**2)/(Npt - 1)**2 for pt in range(Npt)]
U = arange(0, 3, 0.3)
PU = calcul_pu_surface("../../surface-50.dat", U);	S = calcul_spectre_pu(lecture_composantes_fi("total_T0.1350_Fj.out"), PT, U, PU)