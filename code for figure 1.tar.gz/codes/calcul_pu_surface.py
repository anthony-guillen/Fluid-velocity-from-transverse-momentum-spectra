
from math import sqrt

TAU, X, Y, ETA, SIG_TAU, SIG_X, SIG_Y, SIG_ETA, U_TAU, U_X, U_Y, U_ETA = 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11
H = [TAU, X, Y, ETA, SIG_TAU, SIG_X, SIG_Y, SIG_ETA, U_TAU, U_X, U_Y, U_ETA]

#this function takes as input a string with the location of a freeze out surface 
#from a MUSIC output and puts its information in a multidimensionnal array

#in the file, this information is presented as a two
#dimensional array we store it in S, as S[column][row]

def lecture(s):
	S = [[] for h in H];	W = []
	f = open(s);	i = 0
	for l in f: 
		i+=1
		if i % 1 != 0: continue
		
		W = l.split()
		for w in range(len(W)): W[w] = float(W[w])
		for h in H: S[h].append(W[h])
	f.close()
	return S

#this function takes as input an array from the previous function, and an 
#array U and returns the distribution of fluid velocity of the corresponding 
#surface (Omega(u) in the article, see (11)) at the values contained in U

#in the end, it is simply stored in the array P[u]

def calcul_pu_surface(s, U):
	
	S = lecture(s)
	P=[0 for u in range(len(U))];
	
	for s in range(len(S[0])):
		for u in range(len(U)-1):
			if(U[u] <= sqrt((S[U_X][s]**2+S[U_Y][s]**2)) < U[u+1]): 
				
				#this is the implementation of equation (4) in the article; the factor of S[TAU][s] seems to be here in 
				#the way MUSIC stores the surface and the factor 5.068**3 is a conversion of unit between fm and GeV
				
				P[u] += (S[U_TAU][s]*S[SIG_TAU][s]+S[U_X][s]*S[SIG_X][s]+S[U_Y][s]*S[SIG_Y][s])/S[U_TAU][s]*S[TAU][s]*5.068**3
				break	
	return P