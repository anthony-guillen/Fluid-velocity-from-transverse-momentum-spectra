
def lecture_spectres_calcules(s):
	f = open(s);	P = ['pi', 'K', 'p'];	PT = [];	S = [[] for p in P];	W = []
	for l in f:
		W = l.split()
		for w in range(len(W)): W[w] = float(W[w])
		
		PT.append(W[0])
		for p in range(1, len(W)): S[p-1].append(W[p])
	f.close()
	return PT, S