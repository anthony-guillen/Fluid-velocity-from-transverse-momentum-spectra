
from math import atan

PBAR, M, FEQ1, FEQ2 = 0, 1, 2, 3;	H = [PBAR, M, FEQ1, FEQ2];

#this function takes as input a string s with a type of spectrum (thermal or total) 
#and a temperature (for instance, s="total_T0.1350_Fj.out"), and put the information 
#of the corresponding output from the FastReso code in a multidimensionnal array

def lecture_composantes_fi(s):
	
	B = [[] for h in H];	W = []
	
	#we first read the information for all the (anti)-particles in the following list, 
	#with their name as they appear in the composantes_fi_PDG2016+ folder
	
	#in the file, this information is presented as a two dimensional array 
	#for each particle; we store it in B, as B[column][particle][row]
	
	for p in [	'pi+', 'Anti-pi+', 'K+', 'Anti-K+', 'p', 'Anti-p', 'N(1875)+', 'Anti-N(1875)+', 
			'Lambda', 'Anti-Lambda', 'Sigma+', 'Anti-Sigma+', 'Sigma-', 'Anti-Sigma-']:
				
		for h in H: B[h].append([])
		f = open("../../composantes_fi_PDG2016+/"+p+"_"+s)
		
		i = 0
		for l in f: 
			i+=1;
			if i <= 3: continue

			W = l.split()
			for w in range(len(W)): W[w] = float(W[w])
			for h in H: B[h][-1].append(W[h])
		f.close()

	#for instance, if s="total_T0.1350_Fj.out", B[FEQ1][3][10] contains 1.69190e-03, 
	#the eleventh entry in the third row in  the"Anti-K+_total_T0.1350_Fj.out" file
	
	#the next few lines are here to combine the information of the particle and antiparticles in a 
	#single array, and remove the pbar from the pbar*feq_1 that are stored in in FastReso outputs
	
	C = [[] for h in H]; P = ['pi', 'K', 'p', 'd', 'l', 's+', 's-']
	
	for p in range(len(P)):
		for h in H: C[h].append([])
		for b in range(len(B[0][p*2])):
			for h in [PBAR, M]: 	C[h][-1].append(B[h][p*2][b])
			for h in [FEQ1, FEQ2]: 	C[h][-1].append((B[h][p*2][b]+B[h][p*2+1][b])/B[PBAR][p*2][b])
			
	return C

#this function takes as input a multidimensionnal array from the previous 
#function, and a value of pbar, and returns feq1 and feq2 for this value

def lecture_coefficients_f(C, pbar):
	maxpbar = 9.0;	Npbar = 300
	if(pbar > maxpbar): return 0, 0
	else:
		#from the next line we get directly the index of the entry
		#that corresponds to a given pbar in a FastReso output
		c = int(Npbar*atan(pbar)/atan(maxpbar))-1
		
		return C[FEQ1][c], C[FEQ2][c]
	